exports.vnToxic = [
"https://cdn.filestackcontent.com/zdj4WDdSAiy9SpbTTZj7",
"https://cdn.filestackcontent.com/Zdfunz5gQLeTCF4DlQOW",
"https://cdn.filestackcontent.com/YYG9wdIgRLSHi5Or45dO",
"https://cdn.filestackcontent.com/An4uBvGOQ5iuQWAJqlp5",
"https://cdn.filestackcontent.com/lYHaYLVNS4G7QSagNEvX"
]
exports.vnMenu = [
"https://huggingface.co/spaces/BLUESERVER/DATABASE/resolve/main/first.mp3",
"https://huggingface.co/spaces/BLUESERVER/DATABASE/resolve/main/second.mp3",
"https://huggingface.co/spaces/BLUESERVER/DATABASE/resolve/main/1001056127.mp3"
]
exports.vnOwner = [ 
"https://cdn.filestackcontent.com/u6ivfrjHSiqifCvnCvEA",
   "https://cdn.filestackcontent.com/xIuf4mJ9RkSGJAXye9JA",
 "https://cdn.filestackcontent.com/gOGmQMpkQWG7iQcaM6Cd"
]
exports.vnAra = [ 
   "https://cdn.filestackcontent.com/w7FUUZRnKnBbW3JBPXgw",
"https://cdn.filestackcontent.com/3A8QclaSMSoruULZsb6w"
    ]
exports.vnBot = [ 
   "https://cdn.filestackcontent.com/u6YY3T2WRhCx9wgHd84y",
"https://cdn.filestackcontent.com/aQhw3WDBQHC6TOn1J6FF",
"https://cdn.filestackcontent.com/z9jSPfkJRA2wZefh9Exg",
"https://cdn.filestackcontent.com/3Mcm018pRW7gYot1Nv5I"
    ]
exports.vnSalam = [ "https://cdn.filestackcontent.com/CCN0AzPQhuqaG9zXRrFg"]
exports.vnSpam = [ "https://cdn.filestackcontent.com/wlGqcb1RVOT9YOTzI9kz"]
exports.vnPagi = [ "https://cdn.filestackcontent.com/5B3I5N2jQ2WJCr8lblNv",
 "https://cdn.filestackcontent.com/BdeSoIRwTE65TC08Gz3k"             ]
exports.vnSiang = [ 
 "https://cdn.filestackcontent.com/X5S3BPlkQGCDjUmDnuWn" ]
exports.vnMalam = [ "https://cdn.filestackcontent.com/TbQKutSEKhzuQW75Eigg" ]

exports.vnKawai = [ "https://cdn.filestackcontent.com/zHMFviWeT6eDOvu3eJe3"]
exports.vnLove = [ "https://cdn.filestackcontent.com/kaZNTOQRUiKO1Ve91KO7",
"https://cdn.filestackcontent.com/Qm07O9xxQQygvAlBhzHb"            ]