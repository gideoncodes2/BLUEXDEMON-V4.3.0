<h1 align="center"> BLUEXDEMON-V4</h1>
<p align="center">  
  
***
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR CHOOSING ;BLUEX+DEMON;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+BLUE+DEMON;RELEASED+27.11.24" alt="Typing SVG" /></a>
  </p>
    <a href="https://github.com/BLUEXDEMONl/BLUEXDEMON-V4.git"><img src="https://raw.githubusercontent.com/Bolaolat/BLUE-DEMON-V2/refs/heads/main/bluex.jpg" alt="IMG-20240906-154743-430" border="0"></a>
<p align="center">
<pBLUEXDEMON-V4 align="center">
<a href="https://github.com/BLUEXDEMONl/BLUEXDEMON-V4.git"><img title="Author" src="https://img.shields.io/badge/BLUE DEMON-black?style=for-the-badge&logo=github"></a>
<p align="center">


### 1.`First STAR 🌟 This Repo ` And Then Click Fork Below
<br>
    <a href='https://github.com/BLUEXDEMONl/BLUEXDEMON-V4/fork' target="_blank"><img alt='Fork' src='https://img.shields.io/badge/-Fork-blue?style=for-the-badge&logo=Github&logoColor=white'/></a>
 
  ```bash
  * upload the BLUE DEMON V4 Zip
  * unarchive the zip
  * delete the zip 
  * move the files to ../
* click on the settings.js file and change the number to yours
* tap on start
* wait for 3mins and your bot starts running
* Whatsapp code would be generated,link it
* Bot Connected
```
<br>
    <a href='https://github.com/BLUEXDEMONl/BLUEXDEMON-V4/archive/refs/heads/master.zip' target="_blank"><img alt='DOWNLOAD ZIP' src='https://img.shields.io/badge/-Download Zip File-red?style=for-the-badge&logo=google&logoColor=white'/></a>
 <br>
    <a href='https://bot-hosting.net/?aff=1249249036259823733' target="_blank"><img alt='PANEL' src='https://img.shields.io/badge/-Deploy On Panel-green?style=for-the-badge&logo=WhatsApp&logoColor=white'/></a>
<br>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
### DEPLOY ON TERMUX
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+ FOR TERMUX DEPLOYMENT ⟱" alt="Typing SVG" /></a>

```bash
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/BLUEXDEMONl/BLUEXDEMON-V4.git
cd BLUEXDEMON-V4
yarn install
npm start
```
 
    
### DEPLOY ON CODESPACE 
1. Deploy. `Free`
```bash
npm install
npm start
```
   <a href='https://github.com/codespaces' target="_blank"><img alt='Codespace' src='https://img.shields.io/badge/-Deploy-green?style=for-the-badge&logo=codespace&logoColor=white'/></a>

***

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>    

### CONTRIBUTIONS 
-Contributions to BLUE-DEMON are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request.

<br>
    <a href='https://github.com/BLUEXDEMONl/BLUEXDEMON-V4/issues/new' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/-REPORT ISSUE-red?style=for-the-badge&logo=railway&logoColor=white'/></a>


***
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>    

### LICENSE 
-The BLUE-DEMON is released under the [MIT License](https://opensource.org/licenses/MIT).

-Enjoy the diverse features of the BLUEXDEMON  to enhance your conversations and make your WhatsApp experience more interesting!

***
### DEVELOPER:
**GET In Touch with The Owner**
- [**On WHATSAPP**](https://wa.me/2347041039367)
- [**CHANNEL**](https://whatsapp.com/channel/0029Vah3fKtCnA7oMPTPJm1h) 
***
### WARNING

- **BLUEXDEMON is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use BLUEXDEMON at your own risk by keeping this warning in mind.*
  
  #### ```TOTAL REPO VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/Riasgv2/count.svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### THANKS TO:

- Myself Blue For making This bot
- Toxxic for his support and some cases added 
